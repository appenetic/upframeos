document.readyState === 'loading'
    ? document.addEventListener('DOMContentLoaded', initialize)
    : initialize();

function initialize() {

};
