window.onload = function() {
    setTimeout(function() {
        document.getElementById('logo').style.opacity = 0;
    }, 5000);
};
