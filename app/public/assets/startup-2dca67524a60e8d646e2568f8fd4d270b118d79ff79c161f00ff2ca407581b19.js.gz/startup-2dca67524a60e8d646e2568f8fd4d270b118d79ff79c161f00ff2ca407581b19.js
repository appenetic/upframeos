window.onload = function() {
    setTimeout(function() {
        document.getElementById('main-text').style.opacity = 0;
    }, 5000);
};
